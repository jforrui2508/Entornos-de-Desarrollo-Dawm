<h1><?php 
   $name = $_GET['name'];
   $apellidos = $_GET['apellidos'];
   echo "Hola $name $apellidos";
?></h1>