<?php
    $n = $_GET["n"];
    for($i=1; $i<=$n; $i++) {
        $suma+=$i;
    }
    echo "$suma";
?>